// src/Login.js

import React, { useState, useContext } from 'react';
import './Login.css';
import { FaApple, FaGoogle, FaFacebook } from 'react-icons/fa';
import { UserContext } from './UserContext';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const { setUser } = useContext(UserContext);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Set the user data in context
    setUser({ name, email });
    // Navigate to the home page
    navigate('/home');
  };

  return (
    <div className="login-container">
      <div className="login-header">
        <h1>Jobizz</h1>
        <h2>Welcome Back <span role="img" aria-label="wave">👋</span></h2>
        <p>Let's log in. Apply to jobs!</p>
      </div>
      <form className="login-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="login-input"
          required
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="login-input"
          required
        />
        <button type="submit" className="login-button">Log in</button>
      </form>
      <div className="login-or">
        <span>Or continue with</span>
      </div>
      <div className="login-socials">
        <FaApple className="social-icon" />
        <FaGoogle className="social-icon" />
        <FaFacebook className="social-icon" />
      </div>
      <div className="login-footer">
        <p>Haven't an account? <a href="/register">Register</a></p>
      </div>
    </div>
  );
}

export default Login;
