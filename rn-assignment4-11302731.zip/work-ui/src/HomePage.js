// src/HomePage.js

import React, { useContext } from 'react';
import './HomePage.css';
import { FaSearch, FaEllipsisH } from 'react-icons/fa';
import { FaFacebook, FaGoogle } from 'react-icons/fa';
import { BiUserCircle } from 'react-icons/bi';
import { UserContext } from './UserContext';

const HomePage = () => {
  const { user } = useContext(UserContext);

  return (
    <div className="homepage-container">
      <header className="header">
        <BiUserCircle className="user-avatar" />
        <div className="user-info">
          <h1>{user?.name || 'Guest'}</h1>
          <p>{user?.email || 'guest@example.com'}</p>
        </div>
        <div className="notifications">
          <FaEllipsisH />
        </div>
      </header>

      <div className="search-bar">
        <FaSearch className="search-icon" />
        <input type="text" placeholder="Search a job or position" />
      </div>

      <section className="featured-jobs">
        <div className="section-header">
          <h2>Featured Jobs</h2>
          <button className="see-all">See all</button>
        </div>
        <div className="featured-job">
          <FaFacebook className="job-icon" />
          <div className="job-info">
            <h3>Software Engineer</h3>
            <p>Facebook</p>
          </div>
          <div className="job-details">
            <span>$180.00</span>
            <span>Accra, Ghana</span>
          </div>
        </div>
        <div className="featured-job">
          <FaGoogle className="job-icon" />
          <div className="job-info">
            <h3>Project Manager</h3>
            <p>Google</p>
          </div>
          <div className="job-details">
            <span>$160.00</span>
            <span>New York, US</span>
          </div>
        </div>
      </section>

      <section className="popular-jobs">
        <div className="section-header">
          <h2>Popular Jobs</h2>
        </div>
        <div className="job-item">
          <div className="job-icon">
            <img src="https://via.placeholder.com/40" alt="Burger King" />
          </div>
          <div className="job-info">
            <h3>Jr Executive</h3>
            <p>Burger King</p>
          </div>
          <div className="job-details">
            <span>$96,000/y</span>
            <span>Los Angeles, US</span>
          </div>
        </div>
        <div className="job-item">
          <div className="job-icon">
            <img src="https://via.placeholder.com/40" alt="Beats" />
          </div>
          <div className="job-info">
            <h3>Product Manager</h3>
            <p>Beats</p>
          </div>
          <div className="job-details">
            <span>$84,000/y</span>
            <span>Florida, US</span>
          </div>
        </div>
        <div className="job-item">
          <div className="job-icon">
            <img src="https://via.placeholder.com/40" alt="Facebook" />
          </div>
          <div className="job-info">
            <h3>Product Manager</h3>
            <p>Facebook</p>
          </div>
          <div className="job-details">
            <span>$89,000/y</span>
            <span>Florida, US</span>
          </div>
        </div>
      </section>
    </div>
  );
}

export default HomePage;
